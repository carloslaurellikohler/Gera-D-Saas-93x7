/* @ds-bundle: {"format":4,"namespace":"SafraSinapseDesignSystem_10b212","components":[{"name":"Button","sourcePath":"components/actions/Button.jsx"},{"name":"FAB","sourcePath":"components/actions/FAB.jsx"},{"name":"IconButton","sourcePath":"components/actions/IconButton.jsx"},{"name":"SegmentedButton","sourcePath":"components/actions/SegmentedButton.jsx"},{"name":"Alert","sourcePath":"components/communication/Alert.jsx"},{"name":"Badge","sourcePath":"components/communication/Badge.jsx"},{"name":"ProgressIndicator","sourcePath":"components/communication/ProgressIndicator.jsx"},{"name":"Snackbar","sourcePath":"components/communication/Snackbar.jsx"},{"name":"Tooltip","sourcePath":"components/communication/Tooltip.jsx"},{"name":"BottomSheet","sourcePath":"components/containers/BottomSheet.jsx"},{"name":"Card","sourcePath":"components/containers/Card.jsx"},{"name":"Collapsible","sourcePath":"components/containers/Collapsible.jsx"},{"name":"Modal","sourcePath":"components/containers/Modal.jsx"},{"name":"ScreenFeedback","sourcePath":"components/data/ScreenFeedback.jsx"},{"name":"Skeleton","sourcePath":"components/data/Skeleton.jsx"},{"name":"Table","sourcePath":"components/data/Table.jsx"},{"name":"DatePicker","sourcePath":"components/fields/DatePicker.jsx"},{"name":"Search","sourcePath":"components/fields/Search.jsx"},{"name":"Select","sourcePath":"components/fields/Select.jsx"},{"name":"TextField","sourcePath":"components/fields/TextField.jsx"},{"name":"DotNavigation","sourcePath":"components/navigation/DotNavigation.jsx"},{"name":"Pagination","sourcePath":"components/navigation/Pagination.jsx"},{"name":"Step","sourcePath":"components/navigation/Step.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"Checkbox","sourcePath":"components/selection/Checkbox.jsx"},{"name":"Chip","sourcePath":"components/selection/Chip.jsx"},{"name":"RadioButton","sourcePath":"components/selection/RadioButton.jsx"},{"name":"Slider","sourcePath":"components/selection/Slider.jsx"},{"name":"Switch","sourcePath":"components/selection/Switch.jsx"},{"name":"Avatar","sourcePath":"components/visual/Avatar.jsx"},{"name":"Icon","sourcePath":"components/visual/Icon.jsx"},{"name":"Pictogram","sourcePath":"components/visual/Pictogram.jsx"},{"name":"Tag","sourcePath":"components/visual/Tag.jsx"}],"sourceHashes":{"components/actions/Button.jsx":"a48c816cee1b","components/actions/FAB.jsx":"cf6a8cef4e4e","components/actions/IconButton.jsx":"79db6736809f","components/actions/SegmentedButton.jsx":"9ab19ea3cda8","components/communication/Alert.jsx":"428d6bbbace2","components/communication/Badge.jsx":"1b278ab7ab6d","components/communication/ProgressIndicator.jsx":"00ac8b38ce0c","components/communication/Snackbar.jsx":"fc13943a008d","components/communication/Tooltip.jsx":"cd40a03a865d","components/containers/BottomSheet.jsx":"df6d920f5856","components/containers/Card.jsx":"5aecd3d9a544","components/containers/Collapsible.jsx":"ac448baf99bc","components/containers/Modal.jsx":"584a04f1583e","components/data/ScreenFeedback.jsx":"1924652c61dc","components/data/Skeleton.jsx":"83f2b83deb23","components/data/Table.jsx":"04c35288cef7","components/fields/DatePicker.jsx":"7b74a54c063b","components/fields/Search.jsx":"1d9b07592722","components/fields/Select.jsx":"342f367548e3","components/fields/TextField.jsx":"8802839807e3","components/navigation/DotNavigation.jsx":"c4edb7f35ba1","components/navigation/Pagination.jsx":"0b77b6ee365d","components/navigation/Step.jsx":"35b27c4c3247","components/navigation/Tabs.jsx":"74546de73811","components/selection/Checkbox.jsx":"60087b077c4b","components/selection/Chip.jsx":"c49351af7970","components/selection/RadioButton.jsx":"552e2a1a3ae6","components/selection/Slider.jsx":"5c07ad09944f","components/selection/Switch.jsx":"dcbd52123763","components/visual/Avatar.jsx":"8a047c460e42","components/visual/Icon.jsx":"910af0702004","components/visual/Pictogram.jsx":"fdd21860b962","components/visual/Tag.jsx":"31392087bad3"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.SafraSinapseDesignSystem_10b212 = window.SafraSinapseDesignSystem_10b212 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/actions/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Sinapse Button — emphasis hierarchy: filled > outlined > text.
 * Use the lowest-emphasis variant that fits the context.
 */
function Button({
  variant = "filled",
  size = "medium",
  iconLeft,
  iconRight,
  disabled = false,
  fullWidth = false,
  type = "button",
  onClick,
  children,
  style,
  ...rest
}) {
  const sizes = {
    small: {
      h: 36,
      px: 16,
      fs: 13
    },
    medium: {
      h: 44,
      px: 24,
      fs: 14
    },
    large: {
      h: 52,
      px: 32,
      fs: 16
    }
  };
  const s = sizes[size] || sizes.medium;
  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    height: s.h,
    padding: `0 ${s.px}px`,
    width: fullWidth ? "100%" : undefined,
    borderRadius: "var(--corner-large)",
    fontFamily: "var(--font-plain)",
    fontWeight: 600,
    fontSize: s.fs,
    lineHeight: 1,
    cursor: disabled ? "not-allowed" : "pointer",
    border: "1px solid transparent",
    transition: "background .15s ease, box-shadow .15s ease, opacity .15s ease",
    whiteSpace: "nowrap",
    userSelect: "none",
    ...style
  };
  const variants = {
    filled: {
      background: disabled ? "var(--background-disabled)" : "var(--background-brand-primary-n1)",
      color: disabled ? "var(--content-disabled)" : "var(--content-on-brand-primary)"
    },
    outlined: {
      background: "transparent",
      color: disabled ? "var(--content-disabled)" : "var(--content-primary)",
      borderColor: disabled ? "var(--border-disabled)" : "var(--border-primary)"
    },
    text: {
      background: "transparent",
      color: disabled ? "var(--content-disabled)" : "var(--content-brand-primary)",
      padding: `0 ${Math.max(8, s.px - 12)}px`
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    style: {
      ...base,
      ...variants[variant]
    },
    onMouseDown: e => !disabled && (e.currentTarget.style.transform = "scale(0.98)"),
    onMouseUp: e => e.currentTarget.style.transform = "scale(1)",
    onMouseLeave: e => e.currentTarget.style.transform = "scale(1)"
  }, rest), iconLeft && /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: s.fs + 4
    }
  }, iconLeft), children, iconRight && /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: s.fs + 4
    }
  }, iconRight));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Button.jsx", error: String((e && e.message) || e) }); }

// components/actions/FAB.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse FAB — floating primary action. Use sparingly (one per screen). */
function FAB({
  icon,
  label,
  size = "regular",
  onClick,
  "aria-label": ariaLabel,
  style,
  ...rest
}) {
  const dims = {
    small: 40,
    regular: 56,
    large: 96
  };
  const extended = !!label;
  const d = dims[size] || 56;
  return /*#__PURE__*/React.createElement("button", _extends({
    "aria-label": ariaLabel || label,
    onClick: onClick,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gap: 12,
      height: d,
      width: extended ? "auto" : d,
      padding: extended ? "0 20px" : 0,
      borderRadius: extended ? "var(--corner-large)" : "var(--corner-large)",
      background: "var(--background-brand-primary-n1)",
      color: "var(--content-on-brand-primary)",
      border: "none",
      boxShadow: "var(--elevation-3)",
      cursor: "pointer",
      fontFamily: "var(--font-plain)",
      fontWeight: 600,
      fontSize: 15,
      transition: "box-shadow .15s ease, transform .1s ease",
      ...style
    },
    onMouseEnter: e => e.currentTarget.style.boxShadow = "var(--elevation-4)",
    onMouseLeave: e => e.currentTarget.style.boxShadow = "var(--elevation-3)"
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: size === "large" ? 36 : 24
    }
  }, icon), extended && /*#__PURE__*/React.createElement("span", null, label));
}
Object.assign(__ds_scope, { FAB });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/FAB.jsx", error: String((e && e.message) || e) }); }

// components/actions/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse IconButton — icon-only action. Always supply aria-label. */
function IconButton({
  icon,
  variant = "standard",
  size = "medium",
  disabled = false,
  onClick,
  "aria-label": ariaLabel,
  style,
  ...rest
}) {
  const dim = {
    small: 32,
    medium: 40,
    large: 48
  }[size] || 40;
  const fs = {
    small: 18,
    medium: 22,
    large: 26
  }[size] || 22;
  const variants = {
    standard: {
      background: "transparent",
      color: "var(--content-secondary)"
    },
    filled: {
      background: "var(--background-brand-primary-n1)",
      color: "var(--content-on-brand-primary)"
    },
    tonal: {
      background: "var(--background-brand-primary-n5)",
      color: "var(--content-brand-primary)"
    },
    outlined: {
      background: "transparent",
      color: "var(--content-primary)",
      border: "1px solid var(--border-primary)"
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    "aria-label": ariaLabel,
    disabled: disabled,
    onClick: onClick,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: dim,
      height: dim,
      borderRadius: "var(--corner-full)",
      border: "1px solid transparent",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.4 : 1,
      transition: "background .15s ease",
      ...variants[variant],
      ...style
    },
    onMouseEnter: e => variant === "standard" && !disabled && (e.currentTarget.style.background = "var(--background-hover)"),
    onMouseLeave: e => variant === "standard" && (e.currentTarget.style.background = "transparent")
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: fs
    }
  }, icon));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/actions/SegmentedButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse SegmentedButton — mutually exclusive choice among side-by-side options. */
function SegmentedButton({
  options = [],
  value,
  onChange,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "group",
    style: {
      display: "inline-flex",
      borderRadius: "var(--corner-full)",
      border: "1px solid var(--border-primary)",
      overflow: "hidden",
      fontFamily: "var(--font-plain)",
      ...style
    }
  }, rest), options.map((opt, i) => {
    const val = typeof opt === "string" ? opt : opt.value;
    const label = typeof opt === "string" ? opt : opt.label;
    const icon = typeof opt === "object" ? opt.icon : null;
    const selected = val === value;
    return /*#__PURE__*/React.createElement("button", {
      key: val,
      onClick: () => onChange && onChange(val),
      "aria-pressed": selected,
      style: {
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 6,
        padding: "0 20px",
        height: 40,
        minWidth: 64,
        border: "none",
        borderLeft: i === 0 ? "none" : "1px solid var(--border-primary)",
        background: selected ? "var(--background-selected)" : "transparent",
        color: selected ? "var(--content-brand-primary)" : "var(--content-secondary)",
        fontWeight: selected ? 600 : 500,
        fontSize: 14,
        cursor: "pointer",
        transition: "background .15s ease"
      }
    }, selected && /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded",
      style: {
        fontSize: 18
      }
    }, "check"), icon && !selected && /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded",
      style: {
        fontSize: 18
      }
    }, icon), label);
  }));
}
Object.assign(__ds_scope, { SegmentedButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/SegmentedButton.jsx", error: String((e && e.message) || e) }); }

// components/communication/Alert.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse Alert — persistent inline system message. */
function Alert({
  type = "default",
  size = "medium",
  title,
  action,
  onClose,
  icon,
  children,
  style,
  ...rest
}) {
  const map = {
    default: {
      icon: "chat_bubble",
      bg: "var(--background-secondary)",
      bd: "var(--border-secondary)",
      fg: "var(--content-secondary)"
    },
    info: {
      icon: "info",
      bg: "var(--background-info-n2)",
      bd: "var(--border-info-n2)",
      fg: "var(--content-info)"
    },
    success: {
      icon: "check_circle",
      bg: "var(--background-positive-n2)",
      bd: "var(--border-positive-n2)",
      fg: "var(--content-positive)"
    },
    alert: {
      icon: "warning",
      bg: "var(--background-alert-n2)",
      bd: "var(--border-alert-n2)",
      fg: "var(--content-alert)"
    },
    danger: {
      icon: "error",
      bg: "var(--background-negative-n2)",
      bd: "var(--border-negative-n2)",
      fg: "var(--content-negative)"
    }
  };
  const t = map[type] || map.default;
  const pad = {
    "extra-small": 8,
    small: 12,
    medium: 16,
    large: 20
  }[size] || 16;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "alert",
    style: {
      display: "flex",
      gap: 12,
      alignItems: "flex-start",
      padding: pad,
      background: t.bg,
      border: `1px solid ${t.bd}`,
      borderRadius: "var(--corner-medium)",
      fontFamily: "var(--font-plain)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 22,
      color: t.fg,
      flexShrink: 0
    }
  }, icon || t.icon), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 14,
      color: "var(--content-primary)",
      marginBottom: children ? 2 : 0
    }
  }, title), children && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      lineHeight: "18px",
      color: "var(--content-secondary)"
    }
  }, children), action && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8
    }
  }, action)), onClose && /*#__PURE__*/React.createElement("button", {
    "aria-label": "Fechar",
    onClick: onClose,
    style: {
      background: "none",
      border: "none",
      cursor: "pointer",
      color: "var(--content-tertiary)",
      display: "flex",
      padding: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 20
    }
  }, "close")));
}
Object.assign(__ds_scope, { Alert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/communication/Alert.jsx", error: String((e && e.message) || e) }); }

// components/communication/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse Badge — notification / count indicator overlaid on a parent element. */
function Badge({
  content,
  size = "medium",
  color = "negative",
  children,
  style,
  ...rest
}) {
  const bg = color === "primary" ? "var(--background-brand-primary-n1)" : "var(--background-negative-n1)";
  const fg = color === "primary" ? "var(--content-on-brand-primary)" : "var(--content-white)";
  const isDot = size === "small" || content == null || content === "";
  const dim = isDot ? 8 : size === "large" ? 22 : 18;
  const badge = /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      minWidth: dim,
      height: dim,
      padding: isDot ? 0 : "0 5px",
      background: bg,
      color: fg,
      borderRadius: "var(--corner-full)",
      fontFamily: "var(--font-plain)",
      fontWeight: 600,
      fontSize: size === "large" ? 12 : 10,
      lineHeight: 1,
      boxSizing: "border-box"
    }
  }, !isDot && content);
  if (!children) return badge;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: "relative",
      display: "inline-flex",
      ...style
    }
  }, rest), children, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: -4,
      right: -4
    }
  }, badge));
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/communication/Badge.jsx", error: String((e && e.message) || e) }); }

// components/communication/ProgressIndicator.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse ProgressIndicator — circular (spinner) or linear bar. */
function ProgressIndicator({
  type = "circular",
  value,
  color = "primary",
  size = "medium",
  style,
  ...rest
}) {
  const colors = {
    primary: "var(--content-brand-primary)",
    secondary: "var(--content-brand-secondary)",
    success: "var(--positive)",
    warning: "var(--alert)",
    danger: "var(--negative)"
  };
  const stroke = colors[color] || colors.primary;
  const indeterminate = value == null;
  if (type === "linear") {
    const h = size === "small" ? 4 : 6;
    return /*#__PURE__*/React.createElement("div", _extends({
      style: {
        width: "100%",
        height: h,
        background: "var(--background-tertiary)",
        borderRadius: "var(--corner-full)",
        overflow: "hidden",
        position: "relative",
        ...style
      }
    }, rest), /*#__PURE__*/React.createElement("div", {
      style: {
        height: "100%",
        background: stroke,
        borderRadius: "inherit",
        width: indeterminate ? "40%" : `${value}%`,
        animation: indeterminate ? "sf-linear-indeterminate 1.4s ease-in-out infinite" : "none",
        transition: indeterminate ? "none" : "width .3s ease"
      }
    }), /*#__PURE__*/React.createElement("style", null, `@keyframes sf-linear-indeterminate{0%{margin-left:-40%}100%{margin-left:100%}}`));
  }
  const dim = {
    small: 24,
    medium: 40,
    large: 56
  }[size] || 40;
  const sw = size === "small" ? 3 : 4;
  const r = (dim - sw) / 2;
  const c = 2 * Math.PI * r;
  return /*#__PURE__*/React.createElement("svg", _extends({
    width: dim,
    height: dim,
    viewBox: `0 0 ${dim} ${dim}`,
    style: {
      transform: "rotate(-90deg)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("circle", {
    cx: dim / 2,
    cy: dim / 2,
    r: r,
    fill: "none",
    stroke: "var(--background-tertiary)",
    strokeWidth: sw
  }), /*#__PURE__*/React.createElement("circle", {
    cx: dim / 2,
    cy: dim / 2,
    r: r,
    fill: "none",
    stroke: stroke,
    strokeWidth: sw,
    strokeLinecap: "round",
    strokeDasharray: c,
    strokeDashoffset: indeterminate ? c * 0.7 : c * (1 - value / 100),
    style: {
      transition: indeterminate ? "none" : "stroke-dashoffset .3s ease",
      transformOrigin: "center",
      animation: indeterminate ? "sf-spin 1s linear infinite" : "none"
    }
  }), /*#__PURE__*/React.createElement("style", null, `@keyframes sf-spin{to{transform:rotate(360deg)}}`));
}
Object.assign(__ds_scope, { ProgressIndicator });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/communication/ProgressIndicator.jsx", error: String((e && e.message) || e) }); }

// components/communication/Snackbar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse Snackbar — transient bottom feedback. Auto-dismisses. */
function Snackbar({
  variant = "info",
  size = "medium",
  message,
  action,
  icon,
  showClose,
  onClose,
  style,
  ...rest
}) {
  const map = {
    success: {
      icon: "check_circle",
      fg: "var(--positive)"
    },
    warning: {
      icon: "warning",
      fg: "var(--alert)"
    },
    error: {
      icon: "error",
      fg: "var(--negative)"
    },
    info: {
      icon: "info",
      fg: "var(--info)"
    },
    icon: {
      icon: icon || "notifications",
      fg: "var(--content-white)"
    }
  };
  const t = map[variant] || map.info;
  const pad = {
    small: "8px 12px",
    medium: "12px 16px",
    large: "16px 20px"
  }[size];
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "status",
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 12,
      padding: pad,
      background: "var(--safra-navy)",
      color: "var(--content-white)",
      borderRadius: "var(--corner-small)",
      boxShadow: "var(--elevation-3)",
      fontFamily: "var(--font-plain)",
      fontSize: 14,
      maxWidth: 520,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 20,
      color: t.fg
    }
  }, icon || t.icon), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, message), action && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--safra-red)",
      fontWeight: 600,
      cursor: "pointer"
    }
  }, action), showClose && /*#__PURE__*/React.createElement("button", {
    "aria-label": "Fechar",
    onClick: onClose,
    style: {
      background: "none",
      border: "none",
      cursor: "pointer",
      color: "var(--content-white)",
      display: "flex",
      padding: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 18
    }
  }, "close")));
}
Object.assign(__ds_scope, { Snackbar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/communication/Snackbar.jsx", error: String((e && e.message) || e) }); }

// components/communication/Tooltip.jsx
try { (() => {
/** Sinapse Tooltip — contextual hint on hover/focus. */
function Tooltip({
  label,
  position = "top",
  children,
  style
}) {
  const [open, setOpen] = React.useState(false);
  const pos = {
    top: {
      bottom: "calc(100% + 8px)",
      left: "50%",
      transform: "translateX(-50%)"
    },
    bottom: {
      top: "calc(100% + 8px)",
      left: "50%",
      transform: "translateX(-50%)"
    },
    left: {
      right: "calc(100% + 8px)",
      top: "50%",
      transform: "translateY(-50%)"
    },
    right: {
      left: "calc(100% + 8px)",
      top: "50%",
      transform: "translateY(-50%)"
    }
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-flex",
      ...style
    },
    onMouseEnter: () => setOpen(true),
    onMouseLeave: () => setOpen(false),
    onFocus: () => setOpen(true),
    onBlur: () => setOpen(false)
  }, children, open && /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: "absolute",
      ...pos[position],
      zIndex: 50,
      whiteSpace: "nowrap",
      background: "var(--safra-navy)",
      color: "var(--content-white)",
      padding: "6px 10px",
      borderRadius: "var(--corner-extra-small)",
      fontFamily: "var(--font-plain)",
      fontSize: 12,
      lineHeight: "16px",
      boxShadow: "var(--elevation-2)",
      pointerEvents: "none"
    }
  }, label));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/communication/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/containers/BottomSheet.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse BottomSheet — panel sliding from the bottom (mobile-first). */
function BottomSheet({
  open = true,
  title,
  onClose,
  children,
  style,
  ...rest
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 100,
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "center",
      background: "rgba(0,0,60,0.45)"
    },
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", _extends({
    onClick: e => e.stopPropagation(),
    style: {
      width: "100%",
      maxWidth: 540,
      background: "var(--background-primary)",
      borderRadius: "var(--corner-stack-large) var(--corner-stack-large) 0 0",
      boxShadow: "var(--elevation-5)",
      padding: "12px 20px 24px",
      boxSizing: "border-box",
      fontFamily: "var(--font-plain)",
      maxHeight: "85vh",
      overflow: "auto",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 36,
      height: 4,
      borderRadius: 2,
      background: "var(--border-primary)",
      margin: "0 auto 16px"
    }
  }), title && /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: "0 0 12px",
      fontFamily: "var(--font-brand)",
      fontWeight: 600,
      fontSize: 20,
      color: "var(--content-primary)"
    }
  }, title), children));
}
Object.assign(__ds_scope, { BottomSheet });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/containers/BottomSheet.jsx", error: String((e && e.message) || e) }); }

// components/containers/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse Card — surface grouping related content. */
function Card({
  variant = "elevated",
  elevation = 1,
  padding = 20,
  onClick,
  children,
  style,
  ...rest
}) {
  const variants = {
    filled: {
      background: "var(--background-secondary)",
      border: "1px solid transparent",
      boxShadow: "none"
    },
    outlined: {
      background: "var(--background-primary)",
      border: "1px solid var(--border-secondary)",
      boxShadow: "none"
    },
    elevated: {
      background: "var(--background-primary)",
      border: "1px solid transparent",
      boxShadow: `var(--elevation-${elevation})`
    }
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    style: {
      borderRadius: "var(--corner-medium)",
      padding,
      boxSizing: "border-box",
      fontFamily: "var(--font-plain)",
      color: "var(--content-primary)",
      cursor: onClick ? "pointer" : "default",
      transition: "box-shadow .15s ease",
      ...variants[variant],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/containers/Card.jsx", error: String((e && e.message) || e) }); }

// components/containers/Collapsible.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse Collapsible — expandable/collapsible section. */
function Collapsible({
  title,
  defaultOpen = false,
  children,
  style,
  ...rest
}) {
  const [open, setOpen] = React.useState(defaultOpen);
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      border: "1px solid var(--border-secondary)",
      borderRadius: "var(--corner-medium)",
      fontFamily: "var(--font-plain)",
      overflow: "hidden",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("button", {
    onClick: () => setOpen(o => !o),
    "aria-expanded": open,
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      width: "100%",
      padding: "14px 16px",
      background: "transparent",
      border: "none",
      cursor: "pointer",
      fontFamily: "inherit",
      fontWeight: 600,
      fontSize: 15,
      color: "var(--content-primary)",
      textAlign: "left"
    }
  }, title, /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 22,
      color: "var(--content-secondary)",
      transform: open ? "rotate(180deg)" : "none",
      transition: "transform .2s ease"
    }
  }, "expand_more")), open && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "0 16px 16px",
      fontSize: 14,
      lineHeight: "20px",
      color: "var(--content-secondary)"
    }
  }, children));
}
Object.assign(__ds_scope, { Collapsible });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/containers/Collapsible.jsx", error: String((e && e.message) || e) }); }

// components/containers/Modal.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse Modal — blocking overlay for confirmations & forms. */
function Modal({
  open = true,
  feedback = "standard",
  size = "md",
  title,
  icon,
  actions,
  onClose,
  width,
  children,
  style,
  ...rest
}) {
  if (!open) return null;
  const fb = {
    standard: {
      fg: "var(--content-brand-primary)",
      icon: null
    },
    success: {
      fg: "var(--positive)",
      icon: "check_circle"
    },
    info: {
      fg: "var(--info)",
      icon: "info"
    },
    warning: {
      fg: "var(--alert)",
      icon: "warning"
    },
    negative: {
      fg: "var(--negative)",
      icon: "error"
    },
    icon: {
      fg: "var(--content-brand-primary)",
      icon: icon || "star"
    }
  }[feedback] || {};
  const w = width || (size === "lg" ? "min(90vw, 800px)" : 500);
  return /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 100,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 24,
      background: "rgba(0,0,60,0.45)"
    },
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", _extends({
    onClick: e => e.stopPropagation(),
    style: {
      width: w,
      maxWidth: "100%",
      maxHeight: "88vh",
      overflow: "auto",
      background: "var(--background-primary)",
      borderRadius: "var(--corner-stack-large)",
      boxShadow: "var(--elevation-5)",
      padding: 28,
      boxSizing: "border-box",
      fontFamily: "var(--font-plain)",
      ...style
    }
  }, rest), (fb.icon || icon) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "center",
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 44,
      color: fb.fg
    }
  }, icon || fb.icon)), title && /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: "var(--font-brand)",
      fontWeight: 600,
      fontSize: 22,
      lineHeight: "28px",
      color: "var(--content-primary)",
      textAlign: fb.icon || icon ? "center" : "left"
    }
  }, title), children && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12,
      fontSize: 15,
      lineHeight: "22px",
      color: "var(--content-secondary)",
      textAlign: fb.icon || icon ? "center" : "left"
    }
  }, children), actions && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      justifyContent: "flex-end",
      marginTop: 24
    }
  }, actions)));
}
Object.assign(__ds_scope, { Modal });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/containers/Modal.jsx", error: String((e && e.message) || e) }); }

// components/data/ScreenFeedback.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse ScreenFeedback — full-screen result state with colored semicircle. */
function ScreenFeedback({
  type = "success",
  title,
  description,
  icon,
  actions,
  style,
  ...rest
}) {
  const map = {
    success: {
      color: "var(--positive)",
      icon: "check_circle"
    },
    info: {
      color: "var(--info)",
      icon: "info"
    },
    alert: {
      color: "var(--alert)",
      icon: "error"
    },
    danger: {
      color: "var(--negative)",
      icon: "dangerous"
    },
    brand1: {
      color: "var(--safra-red)",
      icon: "home"
    },
    brand2: {
      color: "var(--safra-navy)",
      icon: "home"
    }
  };
  const t = map[type] || map.success;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      maxWidth: 360,
      textAlign: "center",
      fontFamily: "var(--font-plain)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: 96,
      marginBottom: 24,
      display: "flex",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      bottom: 0,
      width: 180,
      height: 90,
      borderRadius: "90px 90px 0 0",
      background: t.color,
      opacity: 0.12
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      width: 72,
      height: 72,
      borderRadius: "var(--corner-full)",
      background: t.color,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      alignSelf: "flex-end"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 40,
      color: "var(--content-white)"
    }
  }, icon || t.icon))), title && /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: "0 0 8px",
      fontFamily: "var(--font-brand)",
      fontWeight: 600,
      fontSize: 24,
      color: "var(--content-primary)"
    }
  }, title), description && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 15,
      lineHeight: "22px",
      color: "var(--content-secondary)"
    }
  }, description), actions && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12,
      marginTop: 28
    }
  }, actions));
}
Object.assign(__ds_scope, { ScreenFeedback });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ScreenFeedback.jsx", error: String((e && e.message) || e) }); }

// components/data/Skeleton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse Skeleton — animated loading placeholder. */
function Skeleton({
  variant = "text",
  width,
  height,
  animation = "shimmer",
  style,
  ...rest
}) {
  const radius = variant === "circular" ? "var(--corner-full)" : variant === "rectangular" ? "var(--corner-medium)" : "var(--corner-extra-small)";
  const w = width || (variant === "circular" ? 40 : "100%");
  const h = height || (variant === "text" ? 12 : variant === "circular" ? 40 : 120);
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      width: w,
      height: h,
      borderRadius: radius,
      background: "var(--background-tertiary)",
      position: "relative",
      overflow: "hidden",
      animation: animation === "pulse" ? "sf-skel-pulse 1.5s ease-in-out infinite" : "none",
      ...style
    }
  }, rest), animation === "shimmer" && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: "linear-gradient(90deg, transparent, var(--opacity-neutral-inverse-10, rgba(255,255,255,.5)), transparent)",
      transform: "translateX(-100%)",
      animation: "sf-skel-shimmer 1.5s infinite"
    }
  }), /*#__PURE__*/React.createElement("style", null, `@keyframes sf-skel-shimmer{100%{transform:translateX(100%)}}@keyframes sf-skel-pulse{50%{opacity:.5}}`));
}
Object.assign(__ds_scope, { Skeleton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Skeleton.jsx", error: String((e && e.message) || e) }); }

// components/data/Table.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse Table — tabular data with density, row status and selection. */
function Table({
  columns = [],
  rows = [],
  density = "DEFAULT",
  selectable,
  selected = [],
  onSelect,
  style,
  ...rest
}) {
  const pad = {
    COMPACT: "8px 12px",
    DEFAULT: "12px 16px",
    COMFORTABLE: "18px 16px"
  }[density] || "12px 16px";
  const statusColor = {
    success: "var(--positive)",
    warning: "var(--alert)",
    error: "var(--negative)",
    info: "var(--info)"
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      border: "1px solid var(--border-secondary)",
      borderRadius: "var(--corner-medium)",
      overflow: "hidden",
      fontFamily: "var(--font-plain)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("table", {
    style: {
      width: "100%",
      borderCollapse: "collapse",
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      background: "var(--background-secondary)"
    }
  }, selectable && /*#__PURE__*/React.createElement("th", {
    style: {
      width: 44,
      padding: pad
    }
  }), columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    style: {
      padding: pad,
      textAlign: c.align || "left",
      fontWeight: 600,
      fontSize: 12,
      letterSpacing: 0.3,
      textTransform: "uppercase",
      color: "var(--content-tertiary)",
      whiteSpace: "nowrap"
    }
  }, c.label)))), /*#__PURE__*/React.createElement("tbody", null, rows.map(row => {
    const isSel = selected.includes(row.id);
    return /*#__PURE__*/React.createElement("tr", {
      key: row.id,
      style: {
        borderTop: "1px solid var(--border-tertiary)",
        background: isSel ? "var(--background-selected)" : "transparent",
        boxShadow: row.status ? `inset 3px 0 0 ${statusColor[row.status]}` : "none"
      }
    }, selectable && /*#__PURE__*/React.createElement("td", {
      style: {
        padding: pad,
        textAlign: "center"
      }
    }, /*#__PURE__*/React.createElement("input", {
      type: "checkbox",
      checked: isSel,
      onChange: () => onSelect && onSelect(row.id),
      style: {
        accentColor: "var(--safra-red)",
        width: 16,
        height: 16
      }
    })), columns.map(c => /*#__PURE__*/React.createElement("td", {
      key: c.key,
      style: {
        padding: pad,
        textAlign: c.align || "left",
        color: "var(--content-primary)"
      }
    }, c.render ? c.render(row.data[c.key], row) : row.data[c.key])));
  }))));
}
Object.assign(__ds_scope, { Table });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Table.jsx", error: String((e && e.message) || e) }); }

// components/fields/DatePicker.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse DatePicker — inline month calendar (single / range). */
function DatePicker({
  mode = "single",
  value,
  onChange,
  monthDate,
  style,
  ...rest
}) {
  const today = new Date();
  const [view, setView] = React.useState(() => {
    const d = value ? new Date(value) : monthDate ? new Date(monthDate) : today;
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });
  const months = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
  const dows = ["D", "S", "T", "Q", "Q", "S", "S"];
  const firstDow = view.getDay();
  const daysInMonth = new Date(view.getFullYear(), view.getMonth() + 1, 0).getDate();
  const sel = value ? new Date(value) : null;
  const sameDay = (a, b) => a && b && a.getDate() === b.getDate() && a.getMonth() === b.getMonth() && a.getFullYear() === b.getFullYear();
  const cells = [];
  for (let i = 0; i < firstDow; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(view.getFullYear(), view.getMonth(), d));
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      width: 300,
      padding: 16,
      background: "var(--background-primary)",
      border: "1px solid var(--border-secondary)",
      borderRadius: "var(--corner-medium)",
      boxShadow: "var(--elevation-3)",
      fontFamily: "var(--font-plain)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("button", {
    "aria-label": "M\xEAs anterior",
    onClick: () => setView(new Date(view.getFullYear(), view.getMonth() - 1, 1)),
    style: {
      border: "none",
      background: "none",
      cursor: "pointer",
      display: "flex",
      color: "var(--content-secondary)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded"
  }, "chevron_left")), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      fontSize: 15,
      color: "var(--content-primary)"
    }
  }, months[view.getMonth()], " ", view.getFullYear()), /*#__PURE__*/React.createElement("button", {
    "aria-label": "Pr\xF3ximo m\xEAs",
    onClick: () => setView(new Date(view.getFullYear(), view.getMonth() + 1, 1)),
    style: {
      border: "none",
      background: "none",
      cursor: "pointer",
      display: "flex",
      color: "var(--content-secondary)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded"
  }, "chevron_right"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(7,1fr)",
      gap: 2,
      textAlign: "center"
    }
  }, dows.map((d, i) => /*#__PURE__*/React.createElement("div", {
    key: "h" + i,
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: "var(--content-tertiary)",
      padding: "4px 0"
    }
  }, d)), cells.map((d, i) => {
    if (!d) return /*#__PURE__*/React.createElement("div", {
      key: "e" + i
    });
    const selected = sameDay(d, sel);
    const isToday = sameDay(d, today);
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      onClick: () => onChange && onChange(d),
      style: {
        height: 34,
        border: "none",
        borderRadius: "var(--corner-full)",
        cursor: "pointer",
        fontFamily: "inherit",
        fontSize: 13,
        background: selected ? "var(--background-brand-primary-n1)" : "transparent",
        color: selected ? "var(--content-on-brand-primary)" : "var(--content-primary)",
        fontWeight: selected || isToday ? 600 : 400,
        outline: isToday && !selected ? "1px solid var(--border-brand-primary)" : "none"
      }
    }, d.getDate());
  })));
}
Object.assign(__ds_scope, { DatePicker });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/fields/DatePicker.jsx", error: String((e && e.message) || e) }); }

// components/fields/Search.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse Search — dedicated search field. */
function Search({
  value,
  placeholder = "Buscar",
  onChange,
  onClear,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      height: 44,
      padding: "0 14px",
      background: "var(--background-tertiary)",
      borderRadius: "var(--corner-full)",
      fontFamily: "var(--font-plain)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 22,
      color: "var(--content-tertiary)"
    }
  }, "search"), /*#__PURE__*/React.createElement("input", {
    type: "search",
    value: value,
    placeholder: placeholder,
    onChange: e => onChange && onChange(e.target.value),
    style: {
      flex: 1,
      border: "none",
      outline: "none",
      background: "transparent",
      fontFamily: "inherit",
      fontSize: 15,
      color: "var(--content-primary)"
    }
  }), value && /*#__PURE__*/React.createElement("button", {
    "aria-label": "Limpar",
    onClick: () => onClear ? onClear() : onChange && onChange(""),
    style: {
      border: "none",
      background: "none",
      cursor: "pointer",
      display: "flex",
      color: "var(--content-tertiary)",
      padding: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 20
    }
  }, "close")));
}
Object.assign(__ds_scope, { Search });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/fields/Search.jsx", error: String((e && e.message) || e) }); }

// components/fields/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse Select — dropdown, filled or outlined. */
function Select({
  variant = "outlined",
  label,
  value,
  options = [],
  placeholder = "Selecione",
  disabled = false,
  error = false,
  onChange,
  style,
  ...rest
}) {
  const [open, setOpen] = React.useState(false);
  const selected = options.find(o => (typeof o === "string" ? o : o.value) === value);
  const selectedLabel = selected ? typeof selected === "string" ? selected : selected.label : "";
  const borderColor = error ? "var(--border-negative-n1)" : open ? "var(--content-brand-primary)" : "var(--border-primary)";
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      fontFamily: "var(--font-plain)",
      position: "relative",
      ...style
    }
  }, rest), label && /*#__PURE__*/React.createElement("label", {
    style: {
      display: "block",
      fontSize: 13,
      fontWeight: 500,
      color: "var(--content-secondary)",
      marginBottom: 6
    }
  }, label), /*#__PURE__*/React.createElement("button", {
    type: "button",
    disabled: disabled,
    onClick: () => setOpen(o => !o),
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      width: "100%",
      gap: 8,
      height: 48,
      padding: "0 14px",
      borderRadius: "var(--corner-large)",
      background: variant === "filled" ? "var(--background-tertiary)" : "var(--background-primary)",
      border: variant === "filled" ? "1px solid transparent" : `1.5px solid ${borderColor}`,
      borderBottom: variant === "filled" ? `2px solid ${borderColor}` : undefined,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      fontFamily: "inherit",
      fontSize: 15,
      color: selectedLabel ? "var(--content-primary)" : "var(--content-tertiary)"
    }
  }, selectedLabel || placeholder, /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 22,
      color: "var(--content-secondary)",
      transform: open ? "rotate(180deg)" : "none",
      transition: "transform .15s"
    }
  }, "expand_more")), open && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: "calc(100% + 4px)",
      left: 0,
      right: 0,
      zIndex: 30,
      background: "var(--background-primary)",
      border: "1px solid var(--border-secondary)",
      borderRadius: "var(--corner-medium)",
      boxShadow: "var(--elevation-3)",
      padding: 6,
      maxHeight: 260,
      overflow: "auto"
    }
  }, options.map(o => {
    const val = typeof o === "string" ? o : o.value;
    const lab = typeof o === "string" ? o : o.label;
    const sup = typeof o === "object" ? o.supportingText : null;
    const on = val === value;
    return /*#__PURE__*/React.createElement("div", {
      key: val,
      onClick: () => {
        onChange && onChange(val);
        setOpen(false);
      },
      style: {
        padding: "10px 12px",
        borderRadius: "var(--corner-small)",
        cursor: "pointer",
        background: on ? "var(--background-selected)" : "transparent",
        color: on ? "var(--content-brand-primary)" : "var(--content-primary)"
      },
      onMouseEnter: e => !on && (e.currentTarget.style.background = "var(--background-hover)"),
      onMouseLeave: e => !on && (e.currentTarget.style.background = "transparent")
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 14,
        fontWeight: on ? 600 : 500
      }
    }, lab), sup && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "var(--content-tertiary)"
      }
    }, sup));
  })));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/fields/Select.jsx", error: String((e && e.message) || e) }); }

// components/fields/TextField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse TextField — text input, filled or outlined. */
function TextField({
  variant = "outlined",
  label,
  value,
  type = "text",
  placeholder,
  supportingText,
  error,
  errorMessage,
  disabled = false,
  required = false,
  prefixText,
  suffixText,
  maxLength,
  rows,
  onChange,
  style,
  ...rest
}) {
  const [focused, setFocused] = React.useState(false);
  const invalid = !!error;
  const borderColor = invalid ? "var(--border-negative-n1)" : focused ? "var(--content-brand-primary)" : "var(--border-primary)";
  const isTextarea = !!rows;
  const Field = isTextarea ? "textarea" : "input";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-plain)",
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    style: {
      display: "block",
      fontSize: 13,
      fontWeight: 500,
      color: "var(--content-secondary)",
      marginBottom: 6
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--content-negative)"
    }
  }, " *")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: isTextarea ? "flex-start" : "center",
      gap: 8,
      padding: isTextarea ? "12px 14px" : "0 14px",
      minHeight: isTextarea ? undefined : 48,
      borderRadius: "var(--corner-large)",
      background: variant === "filled" ? "var(--background-tertiary)" : "var(--background-primary)",
      border: variant === "filled" ? "1px solid transparent" : `1.5px solid ${borderColor}`,
      borderBottom: variant === "filled" ? `2px solid ${borderColor}` : undefined,
      opacity: disabled ? 0.5 : 1
    }
  }, prefixText && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      color: "var(--content-tertiary)"
    }
  }, prefixText), /*#__PURE__*/React.createElement(Field, _extends({
    type: type,
    value: value,
    placeholder: placeholder,
    disabled: disabled,
    required: required,
    maxLength: maxLength,
    rows: rows,
    onChange: e => onChange && onChange(e.target.value),
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false),
    style: {
      flex: 1,
      border: "none",
      outline: "none",
      background: "transparent",
      fontFamily: "inherit",
      fontSize: 15,
      color: "var(--content-primary)",
      padding: isTextarea ? 0 : "12px 0",
      resize: isTextarea ? "vertical" : undefined
    }
  }, rest)), suffixText && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      color: "var(--content-tertiary)"
    }
  }, suffixText), invalid && /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 20,
      color: "var(--content-negative)"
    }
  }, "error")), invalid && errorMessage ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--content-negative)",
      marginTop: 6,
      display: "flex",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("span", null, errorMessage), maxLength && /*#__PURE__*/React.createElement("span", null, (value || "").length, "/", maxLength)) : supportingText || maxLength ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--content-tertiary)",
      marginTop: 6,
      display: "flex",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("span", null, supportingText), maxLength && /*#__PURE__*/React.createElement("span", null, (value || "").length, "/", maxLength)) : null);
}
Object.assign(__ds_scope, { TextField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/fields/TextField.jsx", error: String((e && e.message) || e) }); }

// components/navigation/DotNavigation.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse DotNavigation — position indicator for carousels/slides. */
function DotNavigation({
  count = 3,
  active = 0,
  onChange,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      ...style
    }
  }, rest), Array.from({
    length: count
  }).map((_, i) => {
    const on = i === active;
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      "aria-label": `Ir para ${i + 1}`,
      "aria-current": on,
      onClick: () => onChange && onChange(i),
      style: {
        width: on ? 24 : 8,
        height: 8,
        padding: 0,
        border: "none",
        borderRadius: "var(--corner-full)",
        background: on ? "var(--content-brand-primary)" : "var(--border-primary)",
        cursor: "pointer",
        transition: "width .2s ease, background .2s ease"
      }
    });
  }));
}
Object.assign(__ds_scope, { DotNavigation });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/DotNavigation.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Pagination.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse Pagination — page navigation for large datasets. */
function Pagination({
  page = 1,
  totalPages = 1,
  onChange,
  size = "md",
  iconsOnly = false,
  siblings = 1,
  style,
  ...rest
}) {
  const dim = {
    sm: 32,
    md: 40,
    lg: 48
  }[size] || 40;
  const go = p => p >= 1 && p <= totalPages && onChange && onChange(p);
  const pages = [];
  if (!iconsOnly) {
    const start = Math.max(2, page - siblings);
    const end = Math.min(totalPages - 1, page + siblings);
    pages.push(1);
    if (start > 2) pages.push("…");
    for (let p = start; p <= end; p++) pages.push(p);
    if (end < totalPages - 1) pages.push("…");
    if (totalPages > 1) pages.push(totalPages);
  }
  const cell = (content, opts = {}) => /*#__PURE__*/React.createElement("button", {
    key: opts.key,
    disabled: opts.disabled,
    onClick: opts.onClick,
    "aria-current": opts.active ? "page" : undefined,
    style: {
      minWidth: dim,
      height: dim,
      padding: "0 8px",
      borderRadius: "var(--corner-small)",
      border: opts.active ? "1px solid var(--border-brand-primary)" : "1px solid transparent",
      background: opts.active ? "var(--background-brand-primary-n5)" : "transparent",
      color: opts.disabled ? "var(--content-disabled)" : opts.active ? "var(--content-brand-primary)" : "var(--content-secondary)",
      fontFamily: "var(--font-plain)",
      fontSize: 14,
      fontWeight: opts.active ? 600 : 500,
      cursor: opts.disabled || content === "…" ? "default" : "pointer",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, content);
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
      ...style
    }
  }, rest), cell(/*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 20
    }
  }, "chevron_left"), {
    key: "prev",
    disabled: page === 1,
    onClick: () => go(page - 1)
  }), pages.map((p, i) => p === "…" ? cell("…", {
    key: "e" + i
  }) : cell(p, {
    key: p,
    active: p === page,
    onClick: () => go(p)
  })), cell(/*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 20
    }
  }, "chevron_right"), {
    key: "next",
    disabled: page === totalPages,
    onClick: () => go(page + 1)
  }));
}
Object.assign(__ds_scope, { Pagination });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Pagination.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Step.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse Step — multi-step flow progress indicator. Segments clickable. */
function Step({
  steps = [],
  current = 0,
  onStepClick,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      alignItems: "center",
      width: "100%",
      fontFamily: "var(--font-plain)",
      ...style
    }
  }, rest), steps.map((label, i) => {
    const done = i < current;
    const active = i === current;
    const clickable = i <= current && onStepClick;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: i
    }, /*#__PURE__*/React.createElement("div", {
      onClick: () => clickable && onStepClick(i),
      style: {
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 6,
        cursor: clickable ? "pointer" : "default"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 32,
        height: 32,
        borderRadius: "var(--corner-full)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: 14,
        fontWeight: 600,
        flexShrink: 0,
        background: done ? "var(--background-brand-primary-n1)" : active ? "var(--background-primary)" : "var(--background-tertiary)",
        color: done ? "var(--content-on-brand-primary)" : active ? "var(--content-brand-primary)" : "var(--content-tertiary)",
        border: active ? "2px solid var(--content-brand-primary)" : "2px solid transparent"
      }
    }, done ? /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded",
      style: {
        fontSize: 18
      }
    }, "check") : i + 1), label && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        fontWeight: active ? 600 : 500,
        color: active ? "var(--content-primary)" : "var(--content-tertiary)",
        whiteSpace: "nowrap"
      }
    }, label)), i < steps.length - 1 && /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        height: 2,
        margin: "0 8px",
        marginBottom: label ? 22 : 0,
        background: done ? "var(--content-brand-primary)" : "var(--border-secondary)"
      }
    }));
  }));
}
Object.assign(__ds_scope, { Step });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Step.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse Tabs — organize content into views on the same page. */
function Tabs({
  tabs = [],
  value,
  onChange,
  variant = "primary",
  iconMode = "stacked",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist",
    style: {
      display: "flex",
      gap: variant === "secondary" ? 8 : 0,
      borderBottom: variant === "primary" ? "1px solid var(--border-secondary)" : "none",
      fontFamily: "var(--font-plain)",
      ...style
    }
  }, rest), tabs.map(tab => {
    const val = typeof tab === "string" ? tab : tab.value;
    const label = typeof tab === "string" ? tab : tab.label;
    const icon = typeof tab === "object" ? tab.icon : null;
    const active = val === value;
    const stacked = iconMode === "stacked" && icon;
    if (variant === "secondary") {
      return /*#__PURE__*/React.createElement("button", {
        key: val,
        role: "tab",
        "aria-selected": active,
        onClick: () => onChange && onChange(val),
        style: {
          display: "inline-flex",
          alignItems: "center",
          gap: 6,
          padding: "8px 16px",
          border: "none",
          borderRadius: "var(--corner-full)",
          cursor: "pointer",
          fontFamily: "inherit",
          fontSize: 14,
          fontWeight: active ? 600 : 500,
          background: active ? "var(--background-brand-primary-n1)" : "var(--background-tertiary)",
          color: active ? "var(--content-on-brand-primary)" : "var(--content-secondary)",
          transition: "background .15s ease"
        }
      }, icon && /*#__PURE__*/React.createElement("span", {
        className: "material-symbols-rounded",
        style: {
          fontSize: 18
        }
      }, icon), label);
    }
    return /*#__PURE__*/React.createElement("button", {
      key: val,
      role: "tab",
      "aria-selected": active,
      onClick: () => onChange && onChange(val),
      style: {
        display: "inline-flex",
        flexDirection: stacked ? "column" : "row",
        alignItems: "center",
        gap: stacked ? 4 : 6,
        padding: "12px 20px",
        border: "none",
        background: "transparent",
        cursor: "pointer",
        fontFamily: "inherit",
        fontSize: 14,
        fontWeight: active ? 600 : 500,
        color: active ? "var(--content-brand-primary)" : "var(--content-secondary)",
        borderBottom: active ? "2px solid var(--content-brand-primary)" : "2px solid transparent",
        marginBottom: -1,
        transition: "color .15s ease"
      }
    }, icon && /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded",
      style: {
        fontSize: 20
      }
    }, icon), label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/selection/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse Checkbox — non-exclusive multi-selection. */
function Checkbox({
  checked = false,
  indeterminate = false,
  disabled = false,
  label,
  onChange,
  style,
  ...rest
}) {
  const on = checked || indeterminate;
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 10,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      fontFamily: "var(--font-plain)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      width: 20,
      height: 20,
      borderRadius: "var(--corner-extra-small)",
      flexShrink: 0,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      background: on ? "var(--background-brand-primary-n1)" : "transparent",
      border: on ? "2px solid var(--background-brand-primary-n1)" : "2px solid var(--border-primary)",
      transition: "background .12s ease, border-color .12s ease"
    }
  }, indeterminate ? /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 18,
      color: "var(--content-on-brand-primary)"
    }
  }, "remove") : checked && /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 18,
      color: "var(--content-on-brand-primary)"
    }
  }, "check")), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--content-primary)"
    }
  }, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/selection/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/selection/Chip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse Chip — compact selection/action item. Use within a chip set. */
function Chip({
  type = "filter",
  label,
  icon,
  selected = false,
  disabled = false,
  onClick,
  onRemove,
  style,
  ...rest
}) {
  const removable = type === "input" && onRemove;
  return /*#__PURE__*/React.createElement("button", _extends({
    onClick: disabled ? undefined : onClick,
    "aria-pressed": type === "filter" ? selected : undefined,
    disabled: disabled,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      height: 32,
      padding: "0 12px",
      borderRadius: "var(--corner-small)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      fontFamily: "var(--font-plain)",
      fontSize: 13,
      fontWeight: 500,
      border: selected ? "1px solid var(--border-brand-primary)" : "1px solid var(--border-primary)",
      background: selected ? "var(--background-brand-primary-n5)" : "var(--background-primary)",
      color: selected ? "var(--content-brand-primary)" : "var(--content-secondary)",
      transition: "background .15s ease, border-color .15s ease",
      ...style
    }
  }, rest), type === "filter" && selected && /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 16
    }
  }, "check"), icon && !(type === "filter" && selected) && /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 16
    }
  }, icon), label, removable && /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 16,
      marginRight: -4
    },
    onClick: e => {
      e.stopPropagation();
      onRemove();
    }
  }, "close"));
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/selection/Chip.jsx", error: String((e && e.message) || e) }); }

// components/selection/RadioButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse RadioButton — single selection within a group. */
function RadioButton({
  checked = false,
  disabled = false,
  label,
  value,
  name,
  onChange,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 10,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      fontFamily: "var(--font-plain)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    onClick: () => !disabled && onChange && onChange(value),
    style: {
      width: 20,
      height: 20,
      borderRadius: "var(--corner-full)",
      flexShrink: 0,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      border: checked ? "2px solid var(--content-brand-primary)" : "2px solid var(--border-primary)",
      transition: "border-color .12s ease"
    }
  }, checked && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: "var(--corner-full)",
      background: "var(--content-brand-primary)"
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--content-primary)"
    }
  }, label));
}
Object.assign(__ds_scope, { RadioButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/selection/RadioButton.jsx", error: String((e && e.message) || e) }); }

// components/selection/Slider.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse Slider — select a value within a continuous range. */
function Slider({
  min = 0,
  max = 100,
  value = 0,
  step = 1,
  disabled = false,
  onChange,
  showValue = false,
  formatValue,
  style,
  ...rest
}) {
  const pct = (value - min) / (max - min) * 100;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      fontFamily: "var(--font-plain)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      flex: 1,
      height: 20,
      display: "flex",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      right: 0,
      height: 4,
      borderRadius: "var(--corner-full)",
      background: "var(--background-tertiary)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      width: `${pct}%`,
      height: 4,
      borderRadius: "var(--corner-full)",
      background: "var(--background-brand-primary-n1)"
    }
  }), /*#__PURE__*/React.createElement("input", {
    type: "range",
    min: min,
    max: max,
    step: step,
    value: value,
    disabled: disabled,
    onChange: e => onChange && onChange(Number(e.target.value)),
    style: {
      position: "absolute",
      left: 0,
      right: 0,
      width: "100%",
      margin: 0,
      appearance: "none",
      background: "transparent",
      cursor: disabled ? "not-allowed" : "pointer"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: `calc(${pct}% - 9px)`,
      width: 18,
      height: 18,
      borderRadius: "var(--corner-full)",
      background: "var(--white)",
      border: "2px solid var(--background-brand-primary-n1)",
      boxShadow: "var(--elevation-1)",
      pointerEvents: "none"
    }
  })), showValue && /*#__PURE__*/React.createElement("span", {
    style: {
      minWidth: 40,
      textAlign: "right",
      fontSize: 14,
      fontWeight: 600,
      color: "var(--content-primary)"
    }
  }, formatValue ? formatValue(value) : value));
}
Object.assign(__ds_scope, { Slider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/selection/Slider.jsx", error: String((e && e.message) || e) }); }

// components/selection/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse Switch — toggle with immediate effect. */
function Switch({
  checked = false,
  disabled = false,
  size = "medium",
  label,
  onChange,
  style,
  ...rest
}) {
  const w = size === "large" ? 52 : 44;
  const h = size === "large" ? 30 : 26;
  const knob = h - 8;
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 12,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      fontFamily: "var(--font-plain)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      width: w,
      height: h,
      borderRadius: "var(--corner-full)",
      flexShrink: 0,
      position: "relative",
      background: checked ? "var(--background-brand-primary-n1)" : "var(--border-primary)",
      transition: "background .18s ease"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 4,
      left: checked ? w - knob - 4 : 4,
      width: knob,
      height: knob,
      borderRadius: "var(--corner-full)",
      background: "var(--white)",
      boxShadow: "var(--elevation-1)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      transition: "left .18s ease"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: knob - 4,
      color: checked ? "var(--content-brand-primary)" : "var(--content-tertiary)"
    }
  }, checked ? "check" : "close"))), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--content-primary)"
    }
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/selection/Switch.jsx", error: String((e && e.message) || e) }); }

// components/visual/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse Avatar — user/entity representation (image, letter or icon). */
function Avatar({
  variant = "letter",
  src,
  name = "",
  icon = "person",
  size = 40,
  highlight = false,
  style,
  ...rest
}) {
  const initials = name.split(" ").filter(Boolean).slice(0, 2).map(w => w[0]).join("").toUpperCase();
  const ring = highlight ? {
    boxShadow: "0 0 0 2px var(--background-primary), 0 0 0 4px var(--content-brand-primary)"
  } : {};
  const base = {
    width: size,
    height: size,
    borderRadius: "var(--corner-full)",
    flexShrink: 0,
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
    fontFamily: "var(--font-plain)",
    fontWeight: 600,
    fontSize: size * 0.4,
    ...ring,
    ...style
  };
  if (variant === "image" && src) {
    return /*#__PURE__*/React.createElement("span", _extends({
      style: base
    }, rest), /*#__PURE__*/React.createElement("img", {
      src: src,
      alt: name,
      style: {
        width: "100%",
        height: "100%",
        objectFit: "cover"
      }
    }));
  }
  if (variant === "icon-success") {
    return /*#__PURE__*/React.createElement("span", _extends({
      style: {
        ...base,
        background: "var(--background-positive-n1)",
        color: "var(--content-white)"
      }
    }, rest), /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded",
      style: {
        fontSize: size * 0.55
      }
    }, "check"));
  }
  if (variant === "icon") {
    return /*#__PURE__*/React.createElement("span", _extends({
      style: {
        ...base,
        background: "var(--background-tertiary)",
        color: "var(--content-secondary)"
      }
    }, rest), /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded",
      style: {
        fontSize: size * 0.55
      }
    }, icon));
  }
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      ...base,
      background: "var(--background-brand-secondary-n1)",
      color: "var(--content-white)"
    }
  }, rest), initials || "?");
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/visual/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/visual/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Sinapse Icon — renders a Material Symbols (Rounded) glyph.
 * The Sinapse library (665 icons) is Material-based; load the
 * Material Symbols Rounded font in the host page.
 * Safra-specific glyphs (pix, ia, open_finance…) are documented
 * in ICONOGRAPHY but not shipped here — pass any Material name.
 */
function Icon({
  name,
  size = 24,
  color = "var(--content-secondary)",
  filled = false,
  weight = 400,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    className: "material-symbols-rounded",
    style: {
      fontSize: size,
      color,
      lineHeight: 1,
      userSelect: "none",
      fontVariationSettings: `'FILL' ${filled ? 1 : 0}, 'wght' ${weight}, 'GRAD' 0, 'opsz' 24`,
      ...style
    }
  }, rest), name);
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/visual/Icon.jsx", error: String((e && e.message) || e) }); }

// components/visual/Pictogram.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Sinapse Pictogram — larger decorative visual used in Screen Feedback and
 * editorial content. Rendered here as a tinted circle with a Material glyph
 * (the licensed Sinapse pictogram illustrations are not shipped in this kit).
 */
function Pictogram({
  name = "celebrate",
  size = 96,
  color = "var(--content-brand-primary)",
  style,
  ...rest
}) {
  const glyphMap = {
    celebrate: "celebration",
    idea: "lightbulb",
    fire: "local_fire_department",
    "not-safe": "gpp_bad",
    home: "home"
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      width: size,
      height: size,
      borderRadius: "var(--corner-full)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      background: "color-mix(in srgb, currentColor 12%, transparent)",
      color,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: size * 0.5
    }
  }, glyphMap[name] || name));
}
Object.assign(__ds_scope, { Pictogram });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/visual/Pictogram.jsx", error: String((e && e.message) || e) }); }

// components/visual/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sinapse Tag — compact label for categorization/status. */
function Tag({
  color = "neutral",
  size = "medium",
  icon,
  children,
  style,
  ...rest
}) {
  const palettes = {
    positive: {
      bg: "var(--background-positive-n2)",
      fg: "var(--content-positive)"
    },
    alert: {
      bg: "var(--background-alert-n2)",
      fg: "var(--content-alert)"
    },
    negative: {
      bg: "var(--background-negative-n2)",
      fg: "var(--content-negative)"
    },
    info: {
      bg: "var(--background-info-n2)",
      fg: "var(--content-info)"
    },
    neutral: {
      bg: "var(--background-tertiary)",
      fg: "var(--content-secondary)"
    },
    secondary: {
      bg: "var(--background-secondary)",
      fg: "var(--content-secondary)"
    },
    "brand-primary": {
      bg: "var(--background-brand-primary-n5)",
      fg: "var(--content-brand-primary)"
    },
    brand2: {
      bg: "var(--background-brand-secondary-n5)",
      fg: "var(--content-brand-secondary)"
    },
    "positive-dark": {
      bg: "var(--positive-dark)",
      fg: "var(--content-white)"
    },
    "negative-dark": {
      bg: "var(--negative-dark)",
      fg: "var(--content-white)"
    },
    "info-dark": {
      bg: "var(--info-dark)",
      fg: "var(--content-white)"
    }
  };
  const p = palettes[color] || palettes.neutral;
  const dims = {
    small: {
      h: 20,
      fs: 11,
      px: 8
    },
    medium: {
      h: 24,
      fs: 12,
      px: 10
    },
    large: {
      h: 30,
      fs: 13,
      px: 12
    }
  }[size];
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
      height: dims.h,
      padding: `0 ${dims.px}px`,
      borderRadius: "var(--corner-small)",
      background: p.bg,
      color: p.fg,
      fontFamily: "var(--font-plain)",
      fontWeight: 600,
      fontSize: dims.fs,
      lineHeight: 1,
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: dims.fs + 3
    }
  }, icon), children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/visual/Tag.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.FAB = __ds_scope.FAB;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.SegmentedButton = __ds_scope.SegmentedButton;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.ProgressIndicator = __ds_scope.ProgressIndicator;

__ds_ns.Snackbar = __ds_scope.Snackbar;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.BottomSheet = __ds_scope.BottomSheet;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Collapsible = __ds_scope.Collapsible;

__ds_ns.Modal = __ds_scope.Modal;

__ds_ns.ScreenFeedback = __ds_scope.ScreenFeedback;

__ds_ns.Skeleton = __ds_scope.Skeleton;

__ds_ns.Table = __ds_scope.Table;

__ds_ns.DatePicker = __ds_scope.DatePicker;

__ds_ns.Search = __ds_scope.Search;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.TextField = __ds_scope.TextField;

__ds_ns.DotNavigation = __ds_scope.DotNavigation;

__ds_ns.Pagination = __ds_scope.Pagination;

__ds_ns.Step = __ds_scope.Step;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.RadioButton = __ds_scope.RadioButton;

__ds_ns.Slider = __ds_scope.Slider;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Pictogram = __ds_scope.Pictogram;

__ds_ns.Tag = __ds_scope.Tag;

})();
