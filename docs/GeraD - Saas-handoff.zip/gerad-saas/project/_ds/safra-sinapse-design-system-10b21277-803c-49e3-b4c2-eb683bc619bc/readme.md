# Sinapse Design System — Banco Safra

Recreation of Banco Safra's **Sinapse** institutional design system for design & prototyping. Built from the reference documentation (`uploads/design-system-referencia.md`), which is itself extracted from the official Sinapse catalog.

- **Source doc:** `uploads/design-system-referencia.md`
- **Original catalog (not publicly accessible):** `https://ws-hml.safra.com.br/sfe/apl-sinapse-catalog-sfe`
- **Foundations:** Material Design 3 adaptation, WCAG 2.1 AA, mobile-first, native dark mode.

> No source codebase, Figma file, logo files, or font binaries were supplied — only the reference markdown. Values below are faithful to that doc; see **Caveats** for substitutions.

---

## Brand context

Banco Safra is a Brazilian private bank focused on high-income individuals and corporate clients. Sinapse is its shared component library across digital products (internet banking, app, back-office tools). The visual language is **sober, institutional and trustworthy** — navy-dominant, restrained, dense with information, engineered for accessibility rather than flashy.

**Two brand colors, two roles:**
- **Azul Safra `#00003C`** — the institutional identity color (headers, wordmark, dark surfaces).
- **Dourado Safra `#C7B06A`** — the *action* color: primary buttons, active states, brand accents (`--content-brand-primary`). Because gold is light, text/icons that sit **on** the gold fill use Azul Safra (navy) via `--content-on-brand-primary` for AA contrast.

---

## CONTENT FUNDAMENTALS

- **Language:** Brazilian Portuguese. UI copy is concise, direct and formal-but-warm.
- **Voice:** Institutional and reassuring. Speaks *to* the user with `você` (never `tu`), e.g. "Confira o extrato da sua conta". Imperative for actions: "Confirmar", "Enviar", "Saiba mais".
- **Casing:** Sentence case for body and buttons ("Nova transferência"), not Title Case. Uppercase reserved for small labels/eyebrows ("COMPROVANTE", "SALDO DISPONÍVEL").
- **Numbers & money:** Brazilian format — `R$ 1.200,00` (dot thousands, comma decimals). Dates `DD/MM/AAAA`. Native BR masks for CPF/CNPJ/telefone/CEP.
- **Tone in feedback:** Positive confirmations are brief and celebratory but professional ("Tudo certo!", "Transferência enviada!"). Errors are plain and non-alarming ("Saldo insuficiente").
- **Emoji:** Not used. Iconography carries visual meaning instead.
- **Terminology:** Financial/banking domain — Pix, boleto, TED, Open Finance, extrato, comprovante, conta corrente, poupança, limite, fatura.

---

## VISUAL FOUNDATIONS

- **Color:** Semantic-token driven — components never use raw hex, only role tokens (`--content-primary`, `--background-brand-primary-n1`, …). Navy dominates chrome; red is used sparingly for the single primary action per area. Semantic set: positive `#00C853`, info `#2196F3`, alert `#FFC107`, negative `#B00020`. Full 10-hue × 5-level spectrum available for data-viz/tags.
- **Type:** Two families. **Roboto Slab** (brand serif) for display/headline — gives the institutional, editorial feel. **Montserrat** (plain sans) for all UI, body, labels, forms. Class convention `{family}-{use}-{weight}` (e.g. `brand-headline-semibold`, `plain-body-regular`).
- **Spacing:** 8px base unit; explicit scale (2→120). Utility classes `p*`/`m*` and a flexbox grid (`sf-grid-*`), not a 12-column grid.
- **Corners:** Semantic tokens, generally generous — buttons & fields at `corner-large` (16px), cards at `corner-medium` (12px), pills/avatars/badges at `corner-full` (100px). Cards are soft, not sharp.
- **Elevation:** 7 levels, each a **dual shadow** (crisp key shadow + soft ambient), Material-style. Cards rest at 1–2; dropdowns 3; modals 4; FABs/floating 5. Elevated cards use shadow *instead of* a border.
- **Cards:** three flavors — `filled` (solid secondary bg, no shadow), `outlined` (1px subtle border, transparent bg), `elevated` (shadow, no border). Rounded 12px. No colored-left-border accent pattern.
- **Backgrounds:** Flat, solid surfaces — white/near-white in light, deep navy-black in dark. No gradients, no textures, no illustration-heavy backgrounds. Screen Feedback is the one place a soft colored *semicircle* motif appears.
- **Buttons/hover:** Filled = solid red; hover darkens via opacity overlay; pressed = subtle `scale(0.98)`. Outlined/text rely on `--background-hover` (4% navy tint). Focus uses a distinct `--border-focus` ring (accessibility-first).
- **Animation:** Restrained, functional. Short eases (~120–180ms) on background/opacity/transform. Spinners rotate; linear progress slides; skeletons shimmer/pulse. No bounce, no decorative motion.
- **Transparency/blur:** Modest — overlay scrims (`rgba(0,0,60,0.45)`), opacity token scale for tints. No heavy glassmorphism.
- **Imagery vibe:** Minimal photographic imagery in the system itself; when present it's clean, cool-toned and professional. Meaning is carried by icons/pictograms, not photos.
- **Layout:** Mobile-first, responsive. Bottom sheets and FABs are first-class (mobile). Fixed elements: top app bar, bottom nav (mobile), FAB.

---

## ICONOGRAPHY

- **System:** Sinapse ships **665 Material-based icons** in 17 categories. This kit renders them via **Material Symbols Rounded** (Google Fonts) through the `Icon` component and inline `<span class="material-symbols-rounded">` — load that font in any host page.
- **Style:** Rounded, outlined by default (`FILL 0`), 400 weight, 24px optical size. Consistent stroke.
- **Safra-specific glyphs** (`pix`, `ia`, `open_finance`, `virtual_card`, `transfer_in/out`, `card_machine`, `cash_plus`, `safra`…) are **not shipped** — where a real Safra glyph exists, the nearest Material name is substituted (e.g. `pix`, `credit_card`, `savings`). See **Caveats**.
- **Pictograms:** larger decorative visuals (`celebrate`, `idea`, `fire`, …) used in Screen Feedback — rendered here as tinted circles with a Material glyph placeholder; swap for licensed Sinapse illustrations in production.
- **Emoji / unicode as icons:** never.

---

## Components (namespace `window.SafraSinapseDesignSystem_10b212`)

33 primitives, grouped by concern:

- **actions/** — `Button`, `IconButton`, `FAB`, `SegmentedButton`
- **communication/** — `Alert`, `Badge`, `Snackbar`, `Tooltip`, `ProgressIndicator`
- **containers/** — `Card`, `Modal`, `BottomSheet`, `Collapsible`
- **navigation/** — `Tabs`, `Step`, `Pagination`, `DotNavigation`
- **selection/** — `Checkbox`, `RadioButton`, `Switch`, `Chip`, `Slider`
- **fields/** — `TextField`, `Select`, `DatePicker`, `Search`
- **data/** — `Table`, `ScreenFeedback`, `Skeleton`
- **visual/** — `Icon`, `Pictogram`, `Avatar`, `Tag`

Each directory has `<Name>.jsx`, `<Name>.d.ts`, `<Name>.prompt.md`, and one `@dsCard` demo HTML.

### Intentional additions
- None beyond the source inventory. The `Icon` component wraps Material Symbols because the Sinapse icon font itself was not supplied.

---

## Index / manifest

- `styles.css` — global entry (imports only).
- `tokens/` — `colors.css` (roles + dark theme + spectrum), `typography.css`, `spacing.css`, `elevation.css` (elevation + shape), `fonts.css`.
- `components/<group>/` — the 33 primitives + demo cards.
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Elevation, Shape, Brand).
- `ui_kits/internet-banking/` — full-screen product recreation *(planned — see Caveats)*.
- `slides/` — institutional sample slides *(planned — see Caveats)*.
- `thumbnail.html` — homepage tile. `SKILL.md` — Agent-Skill entry.

---

## CAVEATS — please help me get these right

1. **Fonts substituted.** No font binaries were supplied. Using **Roboto Slab** + **Montserrat** from Google Fonts (both are the exact families named in the doc, so this should be faithful). If Safra uses licensed/self-hosted files, please attach them.
2. **Action color set to Dourado Safra `#C7B06A`** (per your update). The `--safra-red*` token names are kept for compatibility but now hold gold values; text on the gold fill is navy (`--content-on-brand-primary`) for contrast. The semantic `negative` red is unchanged.
3. **Icons substituted.** Sinapse's 665-icon font wasn't provided — using Material Symbols Rounded and mapping Safra-specific glyphs to the nearest Material names. Pictogram illustrations are placeholders. Please share the real icon/pictogram assets if you want pixel-fidelity.
4. **No logo.** No brand mark was supplied, so the wordmark is set in Roboto Slab type. I did **not** invent a logo. Please attach official logo SVGs.
5. **UI kit & sample slides not yet built** (ran out of session). The tokens + all 33 components are complete and compile; the internet-banking UI kit and institutional slides are the next step.
6. **Color naming ambiguity** in the source: the doc calls red `--content-brand-primary` yet lists navy as the "primary brand" color, and its `n1→n5` surface direction conflicts with the Filled-button usage. I resolved this by making `--background-brand-primary-n1` the solid action red (so primary buttons render correctly) and treating navy as the identity color. Flag if you'd prefer a different mapping.
